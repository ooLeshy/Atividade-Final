/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projeto;
import java.sql.*;
/**
 *
 * @author saulo
 */
public class ConnectionProvider {
    public static Connection getCon(){
        try
        {
            Class.forName("mysql-connector-j-9.3.0.jar");
            Connection con = DriverManager.getConnection("jdcb:mysql://localhost:3306/bms","root","Saulo9170@");
            return con;
        }
        catch(Exception e)
        {
        return null;
        }
    }
            
}
